// Cannon Wu
// AndrewID: clwu
package com.example.Project1Task2;

import com.example.Project1Task2.DogModel;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.lang3.StringUtils;

@WebServlet(name = "DogServlet", value = "/getDogInfo")
public class DogServlet extends HttpServlet {

    DogModel dm = null;

    // Initiate servlet by instantiating model
    @Override
    public void init() {
        dm = new DogModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // get the user's dog breed selection if it exists
        String search = request.getParameter("dogSelection");

        String nextView;

        // If search parameter exists, scrape data. Otherwise, display search page
        if (search != null) {
            // Scrape data based on user search parameter
            String dogName = StringUtils.capitalize(request.getParameter("dogSelection"));
            String pictureURL = dm.doPicSearch(search);
            String friendly = dm.doFriendlySearch(search);
            String intelligence = dm.doIntelligenceSearch(search);
            String height = dm.doHeightSearch(search);
            String weight = dm.doWeightSearch(search);
            String lifespan = dm.doLifespanSearch(search);

            // Push scraped data to web page
            request.setAttribute("dogName",dogName);
            request.setAttribute("pictureURL",pictureURL);
            request.setAttribute("friendly",friendly);
            request.setAttribute("intelligence",intelligence);
            request.setAttribute("height",height);
            request.setAttribute("weight",weight);
            request.setAttribute("lifespan",lifespan);

            // Set web page to display results
            nextView = "getDogResult.jsp";
        } else {
            // No search parameter so display search page
            nextView = "index.jsp";
        }
        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
