// Cannon Wu
// AndrewID: clwu
package com.example.Project1Task2;

import com.google.gson.Gson;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.net.*;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Array;
import java.util.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DogModel {

    Random r = new Random(); // Used to select random dog picture

    public String doPicSearch(String searchTag)
            throws UnsupportedEncodingException  {

        searchTag = URLEncoder.encode(searchTag, "UTF-8");
        String pictureURL = "";

        // Querying this URL should returns list of candidate dog pictures
        String dogPicURL =
                "https://dog.ceo/api/breed/"
                        + searchTag
                                + "/images";

        // Fetch the page and use GSON to convert JSON to a Java Map
        String response  = fetch(dogPicURL);
        Gson gson = new Gson();
        Map picMap = gson.fromJson(response, Map.class);

        //Get the list of URLs from the JSON
        ArrayList urlArray = (ArrayList) picMap.get("message");

        // Pick a random photo URL from the list
        int randomInt = r.nextInt(urlArray.size() + 1);
        pictureURL = urlArray.get(randomInt).toString();
        return pictureURL;
    }

    // Make an HTTP request to a given URL
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            // Create HTTPS connection
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
        }
        return response;
    }

    public String doFriendlySearch(String searchTag) throws IOException {
        String friendly = "";

        String url = "https://dogtime.com/dog-breeds/" + searchTag + "#/slide/1";

        // Create Jsoup connection to the given URL
        Document doc = Jsoup.connect(url).get();

        // Find blocks containing star rank data
        Elements charTitles = doc.getElementsByClass("characteristic-stars parent-characteristic");
        Element friendlyBlock = null;
        // Find element block containing friendliness data
        for (Element e : charTitles) {
            if (e.text().contains("All Around Friendliness")) {
                friendlyBlock = e;
            }
        }

        if (friendlyBlock != null) {
            // Select single block containing friendliness star ranking by class type and name
            Element starBlock = friendlyBlock.select("div.characteristic-star-block").first();  //first ensures a single element
            // Get single block's child name which contains star ranking
            String starClass = starBlock.child(0).className();

            // Star rank is last char of child name; Extract last char
            char[] starClassChars = starClass.toCharArray();
            char star = starClassChars[starClassChars.length - 1];

            // Set friendly to star rank value
            friendly = String.valueOf(star);
        }

        return friendly;
    }

    public String doIntelligenceSearch(String searchTag) throws IOException {
        String intelligence = "";
        String url = "https://dogtime.com/dog-breeds/" + searchTag + "#/slide/1";

        // Create Jsoup connection to given url
        Document doc = Jsoup.connect(url).get();

        // Find blocks containing star data
        Elements subCharTitles = doc.getElementsByClass("js-list-item-trigger characteristic-stars");
        Element intelligenceBlock = null;
        // Find element block containing intelligence data
        for (Element e : subCharTitles) {
            if (e.text().contains("Intelligence")) {
                intelligenceBlock = e;
            }
        }

        if (intelligenceBlock != null) {
            // Select single block containing intelligence star ranking by class type and name
            Element starBlock = intelligenceBlock.select("div.characteristic-star-block").first();  //first ensures a single element

            // Get single block's child name which contains star ranking
            String starClass = starBlock.child(0).className();

            // Star rank is last char of child name; Extract last char
            char[] starClassChars = starClass.toCharArray();
            char star = starClassChars[starClassChars.length - 1];

            // Set friendly to star rank value
            intelligence = String.valueOf(star);
        }

        return intelligence;
    }

    public String doHeightSearch(String searchTag) throws IOException {
        String height = "";

        // Create Jsoup connection to given url
        String url = "https://dogtime.com/dog-breeds/" + searchTag + "#/slide/1";
        Document doc = Jsoup.connect(url).get();

        // Find blocks containing vitals data
        Elements vitalCharTitles = doc.getElementsByClass("vital-stat-box");
        Element heightBlock = null;
        // Find element block containing height data
        for (Element e : vitalCharTitles) {
            if (e.text().contains("Height")) {
                heightBlock = e;
            }
        }

        // If height data exists, extract info
        if (heightBlock != null) {
            height = heightBlock.text().substring("Height: ".length());
        }

        return height;
    }

    public String doWeightSearch(String searchTag) throws IOException {
        String weight = "";
        String url = "https://dogtime.com/dog-breeds/" + searchTag + "#/slide/1";

        // Create Jsoup connection to given url
        Document doc = Jsoup.connect(url).get();

        // Find blocks containing vitals data
        Elements vitalCharTitles = doc.getElementsByClass("vital-stat-box");
        Element weightBlock = null;
        // Find element block containing weight data
        for (Element e : vitalCharTitles) {
            if (e.text().contains("Weight")) {
                weightBlock = e;
            }
        }

        // If weight data exists, extract weight info
        if (weightBlock != null) {
            weight = weightBlock.text().substring("Weight: ".length());
        }

        return weight;
    }

    public String doLifespanSearch (String searchTag) throws IOException {
        String lifespan = "";
        String url = "https://dogtime.com/dog-breeds/" + searchTag + "#/slide/1";

        // Create Jsoup connection to given url
        Document doc = Jsoup.connect(url).get();

        // Find blocks containing vitals data
        Elements vitalCharTitles = doc.getElementsByClass("vital-stat-box");
        Element lifespanBlock = null;
        // Find element block containing lifespan data
        for (Element e : vitalCharTitles) {
            if (e.text().contains("Life Span")) {
                lifespanBlock = e;
            }
        }

        // If lifespan data exists, extract info
        if (lifespanBlock != null) {
            lifespan = lifespanBlock.text().substring("Life Span: ".length());
        }

        return lifespan;
    }

}
