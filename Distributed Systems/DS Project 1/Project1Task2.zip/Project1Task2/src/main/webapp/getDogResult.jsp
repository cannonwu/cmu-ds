<%-- Cannon Wu --%>
<%-- AndrewID: clwu --%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Dog Result</title>
</head>
<body>
<h1>Dog: <%= request.getAttribute("dogName")%></h1>
<%-- Display each factoid that was found --%>
<h2>Friendly: <%= request.getAttribute("friendly")%> Stars</h2>
<h2>Intelligence: <%= request.getAttribute("intelligence")%> Stars</h2>
<h2>Height: <%= request.getAttribute("height")%></h2>
<h2>Weight: <%= request.getAttribute("weight")%></h2>
<h2>Lifespan: <%= request.getAttribute("lifespan")%></h2>
<h3>Credit: https://dogtime.com/dog-breeds/profiles</h3>
<%-- Credit scrape site --%>
<% if (request.getAttribute("pictureURL") != null) { %>
<img src="<%= request.getAttribute("pictureURL")%>"><br><br>
<h3>Credit: https://dog.ceo/dog-api/</h3><br>
<% } else { %>
<h2> A picture of a <%= request.getParameter("dogSelection")%> could not be found</h2><br>
<% } %>
<%-- CONTINUE BUTTON --%>
<form action="getDogInfo" method="GET">
    <input type="submit" value="Continue" />
</form>
</body>
</html>

