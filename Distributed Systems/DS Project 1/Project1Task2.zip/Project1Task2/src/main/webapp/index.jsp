<%-- Cannon Wu --%>
<%-- AndrewID: clwu --%>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Project1Task2</title>
</head>
<body>
<h1><%= "Dog Finder" %>
</h1>
<p>Created by Cannon Wu</p>
<h2>Dog Breeds</h2>
<%-- Display search page --%>
<form action="getDogInfo" method="GET">
    <label for="dogs">Choose a dog breed:</label>
    <br><br>
<%-- Create dropdown menu and include each breed --%>
    <select name="dogSelection" id="dogSelection">
        <option value="borzoi">Borzoi</option>
        <option value="boxer">Boxer</option>
        <option value="chihuahua">Chihuahua</option>
        <option value="collie">Collie</option>
        <option value="dachshund">Dachshund</option>
        <option value="dalmatian">Dalmatian</option>
        <option value="maltese">Maltese</option>
        <option value="otterhound">Otterhound</option>
        <option value="poodle">Poodle</option>
        <option value="rottweiler">Rottweiler</option>
        <option value="saluki">Saluki</option>
        <option value="whippet">Whippet</option>
    </select>
    <br><br>
    <input type="submit" value="Submit">
</form>
</body>
</html>