// Cannon Wu
// AndrewID: clwu
package com.example.Project1Task3;

import com.example.Project1Task3.ClickerModel;

import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "ClickerServlet",
        urlPatterns = {"/submit", "/getResults"})
public class ClickerServlet extends HttpServlet {

    ClickerModel cm = null;

    // Initiate servlet by instantiating model
    @Override
    public void init() {
        cm = new ClickerModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

//------------ Determine client device ------------------------------
        String ua = request.getHeader("User-Agent");

        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
//-------------------------------------------------------------------

        String nextView = "";
        // Get the user's answer
        String answer = request.getParameter("answer");

        if (answer != null && request.getServletPath().contains("submit")) {
            // If client has submitted an answer, use model to store answer and choose the result view
            cm.countAnswer(answer);
            request.setAttribute("answer",answer);
            nextView = "submit.jsp";
        } else if (request.getServletPath().contains("getResults")) {
            // Use model to print answer totals
            request.setAttribute("results",cm.printResults());
            nextView = "getResults.jsp";
        } else {
            // No servlet path specified. Show initial prompt
            nextView = "index.jsp";
        }

        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}

