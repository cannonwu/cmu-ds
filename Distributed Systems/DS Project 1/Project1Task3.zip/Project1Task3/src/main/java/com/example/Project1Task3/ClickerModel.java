// Cannon Wu
// AndrewID: clwu
package com.example.Project1Task3;

public class ClickerModel {

    // Class variables keep counting until cleared
    int aCount = 0;
    int bCount = 0;
    int cCount = 0;
    int dCount = 0;

    public void countAnswer(String answer) {
        // Tally user's answer
        if (answer.equals("A")) {
            aCount++;
        } else if (answer.equals("B")) {
            bCount++;
        } else if (answer.equals("C")) {
            cCount++;
        } else if (answer.equals("D")) {
            dCount++;
        }
    }

    public String printResults() {
        String resultSummary;

        if (aCount + bCount + cCount + dCount > 0) {
            // If any results exist, print response summary
            resultSummary = "The results from the survey are as follows:<br><br>" +
                    "A: " + aCount + "<br>" +
                    "B: " + bCount + "<br>" +
                    "C: " + cCount + "<br>" +
                    "D: " + dCount + "<br><br>" +
                    "These results have now been cleared.";

            // Clear answer count
            aCount = 0;
            bCount = 0;
            cCount = 0;
            dCount = 0;
        } else {
            // If results do not exist, notify user
            resultSummary = "There are currently no results.";
        }

        return resultSummary;
    }
}
