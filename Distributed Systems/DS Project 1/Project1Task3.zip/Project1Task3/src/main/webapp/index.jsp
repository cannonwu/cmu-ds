<%-- Cannon Wu --%>
<%-- AndrewID: clwu --%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%= request.getAttribute("doctype") %>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>DS Clicker</title>
    </head>
<body>
<h1>Distributed Systems Class Clicker</h1>
<%-- Display clicker form --%>
    <p>Submit your answer to the current question:</p>
        <form action="submit" method="GET">
            <input type="radio" id="A" name="answer" value="A">
            <label for="A">A</label><br>
            <input type="radio" id="B" name="answer" value="B">
            <label for="B">B</label><br>
            <input type="radio" id="C" name="answer" value="C">
            <label for="C">C</label><br>
            <input type="radio" id="D" name="answer" value="D">
            <label for="D">D</label><br><br>
            <input type="submit" value="Submit">
        </form>
    <br/>
</body>
</html>