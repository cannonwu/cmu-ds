<%-- Cannon Wu --%>
<%-- AndrewID: clwu --%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%= request.getAttribute("doctype") %>

<html>
<head>
    <title>DS Clicker</title>
</head>
<body>
<h1>Distributed Systems Class Clicker</h1>
<%-- Display clicker results --%>
    <p><%= request.getAttribute("results")%></p>
</body>
</html>
