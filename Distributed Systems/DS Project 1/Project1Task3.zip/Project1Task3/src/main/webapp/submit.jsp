<%-- Cannon Wu --%>
<%-- AndrewID: clwu --%>
<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%= request.getAttribute("doctype") %>

<html>
<head>
    <title>DS Clicker</title>
</head>
<body>
<h1>Distributed Systems Class Clicker</h1>
<%-- Display most recent client answer. Redisplay clicker form --%>
    <p>Your response "<%= request.getAttribute("answer")%>" has been registered</p>
    <p>Submit your answer to the current question:</p>
        <form action="submit" method="GET">
            <input type="radio" id="A" name="answer" value="A">
            <label for="A">A</label><br>
            <input type="radio" id="B" name="answer" value="B">
            <label for="B">B</label><br>
            <input type="radio" id="C" name="answer" value="C">
            <label for="C">C</label><br>
            <input type="radio" id="D" name="answer" value="D">
            <label for="D">D</label><br><br>
            <input type="submit" value="Submit">
        </form>
<br/>
</body>
</html>