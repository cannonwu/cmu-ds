<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Project1Task1</title>
</head>
<body>
<h1><%= "Enter data and choose hashing algorithm:" %>
</h1>
<br/>
<%-- Display form for user to enter in string data and choose hashing method --%>
<%-- Form action uses ComputeHashes.java to return server response --%>
<form action="computeHash" method="GET">
    <label for="data">Text data:</label><br>
    <input type="text" id="data" name="data" value="" ><br>
    <input type="radio" id="md5" name="hash_algo" value="MD5" checked> <%-- Default to MD5 --%>
    <label for="md5">MD5</label><br>
    <input type="radio" id="sha256" name="hash_algo" value="SHA-256">
    <label for="sha256">SHA-256</label><br>
    <input type="submit" value="Submit">
</form>
</body>
</html>