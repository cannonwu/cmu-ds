package com.example.Project1Task1;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "computeHashesServlet", urlPatterns = "/computeHash")
public class ComputeHashes extends HttpServlet {
    private String message;

    public void init() {
        message = "Here's your hash:";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        //Get user entry data from initial form
        String userString = request.getParameter("data");
        //Get which radio button was selected and store in a String
        String userAlgo = request.getParameter("hash_algo");

        //Prepare MD5 hash computation
        MessageDigest md = null;
        if (userAlgo.equalsIgnoreCase("MD5")) {
            try {
                md = MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        } else {    //Prepare hash computation in SHA-256
            try {
                md = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        //Compute hash for userString
        md.update(userString.getBytes());

        //Create hexadecimal text hash value
        String hashHex = jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest());

        //Create base 64 notation hash value
        String hashBase64 = jakarta.xml.bind.DatatypeConverter.printHexBinary(md.digest());

        // Print original text, name of the hash, hash value in hexadecimal text and base64 notation
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<p>" + "Your text: " + userString + "</p>");
        out.println("<p>" + "Hash choice: " + userAlgo + "</p>");
        out.println("<p>" + "Hash in hexadecimal text: " + hashHex + "</p>");
        out.println("<p>" + "Hash in base 64 notation: " + hashBase64 + "</p>");
        out.println("</body></html>");
    }

    public void destroy() {
    }
}