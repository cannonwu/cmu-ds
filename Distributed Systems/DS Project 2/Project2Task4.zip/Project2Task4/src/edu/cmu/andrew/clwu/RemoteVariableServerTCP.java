// Cannon Wu
// AndrewID: clwu
package edu.cmu.andrew.clwu;

import java.net.*;
import java.io.*;
import java.util.Scanner;
import java.util.TreeMap;

public class RemoteVariableServerTCP {
    static TreeMap<Integer, Integer> clientMap = new TreeMap<Integer,Integer>();

    // add to client's sum value with clientNum
    public static void add(int userID, int clientNum) {
        System.out.println("Adding " + clientNum + " to " + clientMap.get(userID));
        clientMap.put(userID, clientMap.get(userID) + clientNum);   // overwrite client's sum value
    }

    // subtract from client's sum value with clientNum
    public static void subtract(int userID, int clientNum) {
        System.out.println("Subtracting " + clientNum + " from " + clientMap.get(userID));
        clientMap.put(userID, clientMap.get(userID) - clientNum);   // overwrite client's sum value
    }

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static void main(String args[]) {
        System.out.println("The server is running."); // announce startup

        // initialize treeMap <id, 0>
        for (int i = 0; i < 1000; i++) {
            clientMap.put(i, 0);
        }

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        // --INITIALIZE TCP COMMUNICATIONS-- //
        Socket clientSocket = null;
        try {
            // Create a new server socket
            ServerSocket listenSocket = new ServerSocket(portNum);

            /*
             * Forever,
             *   read a line from the socket
             *   print it to the console
             *   echo it (i.e. write it) back to the client
             */
            while (true) {
                /*
                 * Block waiting for a new connection request from a client.
                 * When the request is received, "accept" it, and the rest
                 * the tcp protocol handshake will then take place, making
                 * the socket ready for reading and writing.
                 */
                clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));


                while (in.hasNext()) {
                    String clientString = in.nextLine();

                    // parse clientString based on type of request
                    if (clientString.startsWith("1")) {
                        String[] clientInputs = clientString.split(",");
                        int userID = Integer.parseInt(clientInputs[1]);
                        int clientNum = Integer.parseInt(clientInputs[2]);
                        System.out.println("Serving User " + userID);
                        System.out.println("Client requested Add operation");
                        // call add method to overwrite client's sum value
                        add(userID, clientNum);
                        // convert user sum to string
                        String reply = String.valueOf(clientMap.get(userID));
                        // send server reply
                        out.println(reply);    // issue datagram packet reply through socket
                        out.flush();
                    } else if (clientString.startsWith("2")) {
                        String[] clientInputs = clientString.split(",");
                        int userID = Integer.parseInt(clientInputs[1]);
                        int clientNum = Integer.parseInt(clientInputs[2]);
                        System.out.println("Serving User " + userID);
                        System.out.println("Client requested Subtract operation");
                        subtract(userID, clientNum);     // call subtract method to overwrite client's sum value
                        // convert user sum to string
                        String reply = String.valueOf(clientMap.get(userID));
                        // send server reply
                        out.println(reply);    // issue datagram packet reply through socket
                        out.flush();
                    } else if (clientString.startsWith("3")) {
                        String[] clientInputs = clientString.split(",");
                        int userID = Integer.parseInt(clientInputs[1]);
                        System.out.println("Serving User " + userID);
                        System.out.println("Client requested Get operation");
                        // convert user sum to string
                        String reply = String.valueOf(clientMap.get(userID));
                        // send server reply
                        out.println(reply);    // issue datagram packet reply through socket
                        out.flush();
                    }
                    System.out.println();
                }
            }

            // Handle exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting (typically by you sending quit signal) clean up sockets
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }
}