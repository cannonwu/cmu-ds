package edu.cmu.andrew.clwu;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class RemoteVariableClientTCP {

    static int serverPort = 0;
    static Socket clientSocket = null;

    public static void openSocket(){
        // arguments supply hostname
        try {
            // set up connection and stream pipeline
            clientSocket = new Socket("localhost", serverPort);
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }
    }

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static int callServer(int requestType, int userID, int userValue) {
        int replySum = 0;

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            // convert each user input into a String
            String requestTypeString = String.valueOf(requestType);
            String userIDString = String.valueOf(userID);
            String userValueString = String.valueOf(userValue);
            // aggregate all user inputs w/ separators
            String fullRequestString = requestTypeString + "," + userIDString + "," + userValueString;
            // send fullRequestString
            out.println(fullRequestString);
            out.flush();
            // --RECEIVE VALUE FROM SERVER-- //
            replySum = Integer.parseInt(in.readLine());

        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }
        return replySum;
    }


    public static void main(String args[]) {
        System.out.println("The client is running."); // announce startup

        // get port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        serverPort = input.nextInt();
        System.out.println();

        // open socket
        openSocket();

        // get user value inputs and loop forever
        while (true) {      // loop forever
            // print menu to console
            System.out.println("1. Add a value to your sum");
            System.out.println("2. Subtract a value from your sum");
            System.out.println("3. Get your sum");
            System.out.println("4. Exit client");
            int menuSelection = input.nextInt();

            if (menuSelection == 1) {
                int requestType = 1;
                System.out.println("Enter value to add:");
                int userValue = input.nextInt();
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else if (menuSelection == 2) {
                int requestType = 2;
                System.out.println("Enter value to subtract:");
                int userValue = input.nextInt();
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else if (menuSelection == 3) {
                int requestType = 3;
                // no userValue
                int userValue = 0;
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else {
                break;
            }
            System.out.println();
        }

        System.out.println("Client side quitting. The remote variable server is still running.");
        try {
            if (clientSocket != null) {
                clientSocket.close();
            }
        } catch (IOException e) {
            // ignore exception on close
        }

    }
}
