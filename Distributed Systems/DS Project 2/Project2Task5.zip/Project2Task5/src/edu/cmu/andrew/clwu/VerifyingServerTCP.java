// Cannon Wu
// AndrewID: clwu
package edu.cmu.andrew.clwu;

import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.TreeMap;

public class VerifyingServerTCP {
    static TreeMap<String, Integer> clientMap = new TreeMap<String,Integer>();

    // Code from https://github.com/CMU-Heinz-95702/Project-2-Client-Server
    public static boolean checkUserID(String publicKey, String userID) throws NoSuchAlgorithmException {
        // hash public key: h(e+n)
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(publicKey.getBytes());
        byte[] publicKeyHash = md.digest();     // publicKeyHash = h(e+n)
        // create mock user ID: 20 least significant bytes of h(e+n), convert to bigInt
        BigInteger mockUserID = new BigInteger(Arrays.copyOfRange(publicKeyHash, publicKeyHash.length - 20, publicKeyHash.length));
        String mockUserIDString = mockUserID.toString();
        if (mockUserIDString.equals(userID)) {
            return true;
        } else {
            return false;
        }
    }

    // Code from https://github.com/CMU-Heinz-95702/Project-2-Client-Server
    /**
     * Verifying proceeds as follows:
     * 1) Decrypt the encryptedHash to compute a decryptedHash
     * 2) Hash the messageToCheck using SHA-256 (be sure to handle
     *    the extra byte as described in the signing method.)
     * 3) If this new hash is equal to the decryptedHash, return true else false.
     *
     * @param messageToCheck  a normal string (4 hex digits) that needs to be verified.
     * @param encryptedHashStr integer string - possible evidence attesting to its origin.
     * @return true or false depending on whether the verification was a success
     * @throws Exception
     */
    public static boolean verify(String messageToCheck, String encryptedHashStr, String e, String n)throws Exception  {

        // Convert encryptedHashStr, e, n to big integer
        BigInteger encryptedHash = new BigInteger(encryptedHashStr);
        BigInteger eBigInt = new BigInteger(e);
        BigInteger nBigInt = new BigInteger(n);

        // Decrypt it
        BigInteger decryptedHash = encryptedHash.modPow(eBigInt, nBigInt);

        // compute the digest with SHA-256
        byte[] bytesOfMessage = messageToCheck.getBytes();
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] bigDigest = md.digest(bytesOfMessage);

        // we add a 0 byte as the most significant byte to keep the value to be signed non-negative.
        byte[] messageDigest = new byte[bigDigest.length + 1];
        messageDigest[0] = 0;   // most significant byte set to 0
        // set messageDigest after 0 byte to all bigDigest bytes
        for (int i = 1; i < messageDigest.length; i++) {
            messageDigest[i] = bigDigest[i-1];
        }

        // From the digest, create a BigInteger
        BigInteger bigIntegerToCheck = new BigInteger(messageDigest);

        // inform the client on how the two compare
        if(bigIntegerToCheck.compareTo(decryptedHash) == 0) {
            return true;
        } else {
            return false;
        }
    }


    // add to client's sum value with clientNum
    public static void add(String userID, int clientNum) {
        if (clientMap.containsKey(userID)) {
            System.out.println("Adding " + clientNum + " to " + clientMap.get(userID));
            clientMap.put(userID, clientMap.get(userID) + clientNum);   // overwrite client's sum value
        } else {
            clientMap.put(userID, clientNum);
        }
    }

    // subtract from client's sum value with clientNum
    public static void subtract(String userID, int clientNum) {
        if (clientMap.containsKey(userID)) {
            System.out.println("Subtracting " + clientNum + " from " + clientMap.get(userID));
            clientMap.put(userID, clientMap.get(userID) - clientNum);   // overwrite client's sum value
        } else {
            clientMap.put(userID, -clientNum);
        }
    }

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static void main(String args[]) {
        System.out.println("The server is running."); // announce startup

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        // --INITIALIZE TCP COMMUNICATIONS-- //
        Socket clientSocket = null;
        try {
            // Create a new server socket
            ServerSocket listenSocket = new ServerSocket(portNum);

            /*
             * Block waiting for a new connection request from a client.
             * When the request is received, "accept" it, and the rest
             * the tcp protocol handshake will then take place, making
             * the socket ready for reading and writing.
             */
            clientSocket = listenSocket.accept();
            // If we get here, then we are now connected to a client.

            // Set up "in" to read from the client socket
            Scanner in;
            in = new Scanner(clientSocket.getInputStream());

            // Set up "out" to write to the client socket
            PrintWriter out;
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            /*
             * Forever,
             *   read a line from the socket
             *   print it to the console
             *   echo it (i.e. write it) back to the client
             */
            while (true) {

                while (in.hasNext()) {
                    String clientString = in.nextLine();
                    // parse client request: requestType, userID, userValue, publicKey, e, n, signature
                    String[] clientInputs = clientString.split(",");
                    String requestType = clientInputs[0];
                    String userID = clientInputs[1];
                    String userValue = clientInputs[2];
                    String publicKey = clientInputs[3];
                    String e = clientInputs[4];
                    String n = clientInputs[5];
                    String signature = clientInputs[6];
                    // concatenate plain text message: requestType, userID, userValue, publicKey, e, n
                    String message = requestType + "," + userID + "," + userValue + "," + publicKey + "," + e + "," + n;

                    // parse clientString based on type of request
                    // only if publicKey hashes to userID: checkUserID()
                    // & request is properly signed: verify()
                    if (checkUserID(publicKey, userID) && verify(message,signature,e,n)) {
                        System.out.println("e: " + e);
                        System.out.println("n: " + n);
                        System.out.println("Signature verified");
                        System.out.println("Serving User " + userID);

                        if (clientString.startsWith("1")) {
                            System.out.println("Client requested Add operation");
                            // call add method to overwrite client's sum value
                            add(userID, Integer.parseInt(userValue));
                            // convert user sum to string
                            String reply = String.valueOf(clientMap.get(userID));
                            // send server reply
                            out.println(reply);    // issue datagram packet reply through socket
                            out.flush();
                        } else if (clientString.startsWith("2")) {
                            System.out.println("Client requested Subtract operation");
                            subtract(userID, Integer.parseInt(userValue));     // call subtract method to overwrite client's sum value
                            // convert user sum to string
                            String reply = String.valueOf(clientMap.get(userID));
                            // send server reply
                            out.println(reply);    // issue datagram packet reply through socket
                            out.flush();
                        } else if (clientString.startsWith("3")) {
                            System.out.println("Client requested Get operation");
                            // convert user sum to string
                            String reply = "";
                            if (clientMap.containsKey(userID)) {
                                reply = String.valueOf(clientMap.get(userID));
                            } else {
                                reply = String.valueOf(0);
                            }
                            // send server reply
                            out.println(reply);    // issue datagram packet reply through socket
                            out.flush();
                        } else {
                            out.println("Error in request");
                            out.flush();
                        }
                        System.out.println();
                    }
                }
            }

            // Handle exceptions
        } catch (IOException | NoSuchAlgorithmException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting (typically by you sending quit signal) clean up sockets
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }
}