// Cannon Wu
// AndrewID: clwu
package edu.cmu.andrew.clwu;

import java.net.*;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class SigningClientTCP {

    static int serverPort = 0;
    static Socket clientSocket = null;
    static BigInteger n; // n is the modulus for both the private and public keys
    static BigInteger e; // e is the exponent of the public key
    static BigInteger d; // d is the exponent of the private key
    static String publicKey;
    static String privateKey;
    static BigInteger userID;

    public static void openSocket(){
        // arguments supply hostname
        try {
            // set up connection and stream pipeline
            clientSocket = new Socket("localhost", serverPort);
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }
    }

    // Code from https://github.com/CMU-Heinz-95702/Project-2-Client-Server
    public static void getKeys() {
        Random rnd = new Random();

        // Step 1: Generate two large random primes.
        // We use 400 bits here, but best practice for security is 2048 bits.
        // Change 400 to 2048, recompile, and run the program again and you will
        // notice it takes much longer to do the math with that many bits.
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);

        // Step 2: Compute n by the equation n = p * q.
        n = p.multiply(q);

        // Step 3: Compute phi(n) = (p-1) * (q-1)
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

        // Step 4: Select a small odd integer e that is relatively prime to phi(n).
        // By convention the prime 65537 is used as the public exponent.
        e = new BigInteger("65537");

        // Step 5: Compute d as the multiplicative inverse of e modulo phi(n).
        d = e.modInverse(phi);

        // print key materials
        System.out.println("e = " + e);  // Step 6: (e,n) is the RSA public key
        System.out.println("d = " + d);  // Step 7: (d,n) is the RSA private key
        System.out.println("n = " + n);  // Modulus for both keys

        // create public key: concatenate e + n
        publicKey = String.valueOf(e) + String.valueOf(n);
        // create private key: concatenate d + n
        privateKey = String.valueOf(d) + String.valueOf(n);

        // print public & private keys
        System.out.println("Public Key: " + publicKey);
        System.out.println("Private Key: " + privateKey);

    }

    // Code from https://github.com/CMU-Heinz-95702/Project-2-Client-Server
    public static void getUserID() throws NoSuchAlgorithmException {
        // hash public key: h(e+n)
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(publicKey.getBytes());
        byte[] publicKeyHash = md.digest();     // publicKeyHash = h(e+n)
        // create user ID: 20 least significant bytes of h(e+n), convert to bigInt
        userID = new BigInteger(Arrays.copyOfRange(publicKeyHash, publicKeyHash.length - 20, publicKeyHash.length));
        // print userID
        System.out.println("UserID: " + userID);
    }

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static int callServer(int requestType, int userValue) {
        int replySum = 0;

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            // convert each plain text message attribute into a String
            String requestTypeString = String.valueOf(requestType);
            String userIDString = String.valueOf(userID);
            String userValueString = String.valueOf(userValue);
            // concatenate plain text message: requestType, userID, userValue, publicKey, e, n
            String message = requestTypeString + "," + userIDString + "," + userValueString + "," + publicKey + "," + e + "," + n;

            // call signing method and pass message to be signed
                // 1. hash message
                // 2. encrypt hashed message using modpow(d,n)
                // 3. add signature to request
            String signature = sign(message);

            // create full request: message + signature
            String fullRequestString = message + "," + signature;

            // send fullRequestString
            out.println(fullRequestString);
            out.flush();
            // --RECEIVE VALUE FROM SERVER-- //
            try {
                replySum = Integer.parseInt(in.readLine());
            } catch (NumberFormatException numberFormatException) {
                numberFormatException.printStackTrace();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }

        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return replySum;
    }

    // Code from https://github.com/CMU-Heinz-95702/Project-2-Client-Server
    /**
     * Signing proceeds as follows:
     * 1) Get the bytes from the string to be signed.
     * 2) Compute a SHA-1 digest of these bytes.
     * 3) Copy these bytes into a byte array that is one byte longer than needed.
     *    The resulting byte array has its extra byte set to zero. This is because
     *    RSA works only on positive numbers. The most significant byte (in the
     *    new byte array) is the 0'th byte. It must be set to zero.
     * 4) Create a BigInteger from the byte array.
     * 5) Encrypt the BigInteger with RSA d and n.
     * 6) Return to the caller a String representation of this BigInteger.
     * @param message a sting to be signed
     * @return a string representing a big integer - the encrypted hash.
     * @throws Exception
     */
    public static String sign(String message) throws Exception {

        // compute the digest with SHA-256
        byte[] bytesOfMessage = message.getBytes();
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] bigDigest = md.digest(bytesOfMessage);

        // we add a 0 byte as the most significant byte to keep the value to be signed non-negative.
        byte[] messageDigest = new byte[bigDigest.length + 1];
        messageDigest[0] = 0;   // most significant byte set to 0
        // set messageDigest after 0 byte to all bigDigest bytes
        for (int i = 1; i < messageDigest.length; i++) {
            messageDigest[i] = bigDigest[i-1];
        }

        // From the digest, create a BigInteger
        BigInteger m = new BigInteger(messageDigest);

        // encrypt the digest with the private key
        BigInteger c = m.modPow(d, n);

        // return this as a big integer string
        return c.toString();
    }


    public static void main(String args[]) throws NoSuchAlgorithmException {
        System.out.println("The client is running."); // announce startup

        // get port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        serverPort = input.nextInt();
        System.out.println();

        // open socket
        openSocket();

        // create public and private keys
        getKeys();

        // create userID from keys
        getUserID();

        // loop forever
        // get user request inputs
        // create request and add signature
        while (true) {      // loop forever
            // print menu to console
            System.out.println("1. Add a value to your sum");
            System.out.println("2. Subtract a value from your sum");
            System.out.println("3. Get your sum");
            System.out.println("4. Exit client");
            int menuSelection = input.nextInt();

            if (menuSelection == 1) {
                int requestType = 1;
                System.out.println("Enter value to add:");
                int userValue = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userValue));
            } else if (menuSelection == 2) {
                int requestType = 2;
                System.out.println("Enter value to subtract:");
                int userValue = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userValue));
            } else if (menuSelection == 3) {
                int requestType = 3;
                // no userValue
                int userValue = 0;
                System.out.println("The result is " + callServer(requestType, userValue));
            } else {
                break;
            }
            System.out.println();
        }

        System.out.println("Client side quitting. The remote variable server is still running.");
        try {
            if (clientSocket != null) {
                clientSocket.close();
            }
        } catch (IOException exception) {
            // ignore exception on close
        }

    }
}
