// Cannon Wu
// AndrewID: clwu
package edu.cmu.andrew.clwu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class RemoteVariableClientUDP {
    static int serverPort = 0;  // initialize static member variable serverPort

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static int callServer(int requestType, int userID, int userValue) {
        // create socket and send datagram to server
        // 1. create socket from member serverPort int given by user
        // 2. cast user inputs to string
        // 3. create datagram with string as message and send
        // 4. receive datagram and parse byte array for reply string sum
        // 5. cast string sum to int and return

        // args give message contents and server hostname
        int replySum = 0;
        DatagramSocket aSocket = null;  // initialize datagram socket
        try {   // surround datagram request process with try/catch block
            // send request
            InetAddress aHost = InetAddress.getByName("localhost"); // set client ip address to localhost
            aSocket = new DatagramSocket(); // instantiate new socket
            // convert each user input into a String
            String requestTypeString = String.valueOf(requestType);
            String userIDString = String.valueOf(userID);
            String userValueString = String.valueOf(userValue);

            String fullRequestString = requestTypeString + "," + userIDString + "," + userValueString;  // aggregate all user inputs w/ separators
            byte[] m = fullRequestString.getBytes();    // convert request string into a byte array

            DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);    // initialize datagram packet request
            aSocket.send(request);      // issue RPC request through socket
            // receive reply
            byte[] buffer = new byte[1000]; // initialize byte array to hold incoming server reply data
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length); // initialize server reply datagram packet
            aSocket.receive(reply); // set reply to incoming datagram packet

            // change sizing of request byte array to build string correctly
            byte[] replyBytes = new byte[reply.getLength()];    // initialize byte array with reply length
            int j = 0;  // demo int to iterate over
            for (int k = 0; k < replyBytes.length; k++) {
                replyBytes[k] = reply.getData()[j];     // copy each request byte into new byte array until request length is met
                j++;
            }

            replySum = Integer.parseInt(new String(replyBytes));    // convert reply byte array into a string, then to an int

        }catch (SocketException e) {System.out.println("Socket: " + e.getMessage());    // catch socket exception
        }catch (IOException e){System.out.println("IO: " + e.getMessage());     // catch IOException
        }finally {if(aSocket != null) aSocket.close();}  // close socket

        return replySum;    // return server calculated, client parsed sum value
    }


    public static void getPort() {       // prompt user for server side port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        serverPort = input.nextInt();
    }


    public static void main(String args[]) throws IOException {
        System.out.println("The client is running."); // announce startup
        getPort();  // call method to prompt user for port number
        System.out.println();

        // prompt user for request type
        Scanner input;
        while (true) {      // loop forever
            // print menu to console
            System.out.println("1. Add a value to your sum");
            System.out.println("2. Subtract a value from your sum");
            System.out.println("3. Get your sum");
            System.out.println("4. Exit client");
            input = new Scanner(System.in);
            int menuSelection = input.nextInt();

            if (menuSelection == 1) {
                int requestType = 1;
                System.out.println("Enter value to add:");
                int userValue = input.nextInt();
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else if (menuSelection == 2) {
                int requestType = 2;
                System.out.println("Enter value to subtract:");
                int userValue = input.nextInt();
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else if (menuSelection == 3) {
                int requestType = 3;
                // no userValue
                int userValue = 0;
                System.out.println("Enter your ID:");
                int userID = input.nextInt();
                System.out.println("The result is " + callServer(requestType, userID, userValue));
            } else {
                break;
            }
            System.out.println();
        }
        System.out.println("Client side quitting. The remote variable server is still running.");
    }
}
