// Cannon Wu
// AndrewID: clwu
package edu.cmu.andrew.clwu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.TreeMap;


public class RemoteVariableServerUDP {
    static TreeMap<Integer, Integer> clientMap = new TreeMap<Integer,Integer>();

    // add to client's sum value with clientNum
    public static void add(int userID, int clientNum) {
        System.out.println("Adding " + clientNum + " to " + clientMap.get(userID));
        clientMap.put(userID, clientMap.get(userID) + clientNum);   // overwrite client's sum value
    }


    // subtract from client's sum value with clientNum
    public static void subtract(int userID, int clientNum) {
        System.out.println("Subtracting " + clientNum + " from " + clientMap.get(userID));
        clientMap.put(userID, clientMap.get(userID) - clientNum);   // overwrite client's sum value
    }

    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static void main(String args[]){
        System.out.println("The server is running."); // announce startup

        // initialize treeMap <id, 0>
        for (int i = 0; i < 1000; i++) {
            clientMap.put(i, 0);
        }

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        DatagramSocket aSocket = null;      // initialize datagram socket
        byte[] buffer = new byte[1000];     // initialize buffer byte array to hold incoming byte data
        try{    // surround datagram receiving and replying process in try/catch block
            aSocket = new DatagramSocket(portNum); // assign socket to listen on this port number
            DatagramPacket request = new DatagramPacket(buffer, buffer.length); // initialize datagram request

            ////////////////////////////////////////////////////////////////////////////
            while(true){    // loop forever
                aSocket.receive(request);   // capture incoming request datagram
                // change sizing of request byte array to build string correctly
                byte[] requestBytes = new byte[request.getLength()];    // initialize byte array with request length
                int j = 0;  // demo int to iterate over
                for (int i = 0; i < requestBytes.length; i++) {
                    requestBytes[i] = request.getData()[j];     // copy each request byte into new byte array until request length is met
                    j++;
                }
                String clientString = new String(requestBytes); // convert request bytes into a string
                // parse clientString based on type of request
                if (clientString.startsWith("1")) {
                    String[] clientInputs = clientString.split(",");
                    int userID = Integer.parseInt(clientInputs[1]);
                    int clientNum = Integer.parseInt(clientInputs[2]);
                    System.out.println("Serving User " + userID);
                    System.out.println("Client requested Add operation");
                    add(userID, clientNum);     // call add method to overwrite client's sum value
                    // send datagram
                    String replyString = String.valueOf(clientMap.get(userID));   // convert computed sum value to string
                    byte[] m = replyString.getBytes();  // create byte array from string value of sum

                    DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort()); // initialize reply datagram
                    System.out.println("Returning sum of " + clientMap.get(userID) + " to client"); // print string built from request byte data
                    aSocket.send(reply);    // issue datagram packet reply through socket
                } else if (clientString.startsWith("2")) {
                    String[] clientInputs = clientString.split(",");
                    int userID = Integer.parseInt(clientInputs[1]);
                    int clientNum = Integer.parseInt(clientInputs[2]);
                    System.out.println("Serving User " + userID);
                    System.out.println("Client requested Subtract operation");
                    subtract(userID, clientNum);     // call subtract method to overwrite client's sum value
                    // send datagram
                    String replyString = String.valueOf(clientMap.get(userID));   // convert computed sum value to string
                    byte[] m = replyString.getBytes();  // create byte array from string value of sum
                    DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort()); // initialize reply datagram
                    System.out.println("Returning sum of " + clientMap.get(userID) + " to client"); // print string built from request byte data
                    aSocket.send(reply);    // issue datagram packet reply through socket
                } else if (clientString.startsWith("3")) {
                    String[] clientInputs = clientString.split(",");
                    int userID = Integer.parseInt(clientInputs[1]);
                    System.out.println("Serving User " + userID);
                    System.out.println("Client requested Get operation");
                    // send datagram
                    String replyString = String.valueOf(clientMap.get(userID));   // convert sum value to string
                    byte[] m = replyString.getBytes();  // create byte array from string value of sum
                    DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort()); // initialize reply datagram
                    System.out.println("Returning sum of " + clientMap.get(userID) + " to client"); // print string built from request byte data
                    aSocket.send(reply);    // issue datagram packet reply through socket
                }
                System.out.println();
            }
            /////////////////////////////////////////////////////////////////////////////

        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());     // catch SocketException
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());    // catch IOException
        }finally {if(aSocket != null) aSocket.close();}     // close socket
    }
}
