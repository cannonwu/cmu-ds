package edu.cmu.andrew.clwu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class AddingClientUDP {
    static int serverPort = 0;

    public static int add(int i) {
        // create socket and send datagram to server
        // 1. create socket from member serverPort int given by user
        // 2. cast int i to string
        // 3. create datagram with string as message and send
        // 4. receive datagram and parse byte array for reply string sum
        // 5. cast string sum to int and return

        // args give message contents and server hostname
        int replySum = 0;
        DatagramSocket aSocket = null;  // initialize datagram socket
        try {   // surround datagram request process with try/catch block
            // send request
            InetAddress aHost = InetAddress.getByName("localhost"); // set client ip address to localhost
            aSocket = new DatagramSocket(); // instantiate new socket
            String clientString = String.valueOf(i);    // convert user number into a string
            byte[] m = clientString.getBytes();         // convert string containing user number into a byte array
            DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);    // initialize datagram packet request
            aSocket.send(request);      // issue RPC request through socket
            // receive reply
            byte[] buffer = new byte[1000]; // initialize byte array to hold incoming server reply data
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length); // initialize server reply datagram packet
            aSocket.receive(reply); // set reply to incoming datagram packet

            // change sizing of request byte array to build string correctly
            byte[] replyBytes = new byte[reply.getLength()];    // initialize byte array with reply length
            int j = 0;  // demo int to iterate over
            for (int k = 0; k < replyBytes.length; k++) {
                replyBytes[k] = reply.getData()[j];     // copy each request byte into new byte array until request length is met
                j++;
            }

            replySum = Integer.parseInt(new String(replyBytes));    // convert reply byte array into a string, then to an int

        }catch (SocketException e) {System.out.println("Socket: " + e.getMessage());    // catch socket exception
        }catch (IOException e){System.out.println("IO: " + e.getMessage());     // catch IOException
        }finally {if(aSocket != null) aSocket.close();}  // close socket

        return replySum;    // return server calculated, client parsed sum value
    }

    public static void getPort() {       // prompt user for server side port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        serverPort = input.nextInt();
    }


    public static void main(String args[]) throws IOException {
        System.out.println("The client is running."); // announce startup
        getPort();  // call method to prompt user for port number
        System.out.println();
        // prompt user for number to add
        Scanner input;
        while (true) {      // loop forever
            System.out.println("Enter number:");
            input = new Scanner(System.in);
            int flag = 0;   // flag to handle client side quitting

            while (input.hasNext() ) { // read client input
                try {
                    int i = input.nextInt();
                    System.out.println("The server returned " + add(i)); // do RPC and print return value
                } catch (Exception e) {
                    flag = -1;      // if exception is caught, i.e. client quitting, then flag
                    break;
                }
            }
            if (flag < 0) {
                break;  // if flag is thrown, then quit repeating loop
            }
        }
        System.out.println("Client side quitting.");
    }
}
