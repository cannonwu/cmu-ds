package edu.cmu.andrew.clwu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;


public class AddingServerUDP {
    static int sum = 0;  // initialize a member int to 0

    public static void arithmetic(int clientInt) {  // separate concern for doing arithmetic
        System.out.println("Adding " + clientInt + " to " + sum);
        sum += clientInt;   // add client number to server's sum int
    }

    public static void main(String args[]){
        System.out.println("The server is running."); // announce startup

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        DatagramSocket aSocket = null;      // initialize datagram socket
        byte[] buffer = new byte[1000];     // initialize buffer byte array to hold incoming byte data
        try{    // surround datagram receiving and replying process in try/catch block
            aSocket = new DatagramSocket(portNum); // assign socket to listen on this port number
            DatagramPacket request = new DatagramPacket(buffer, buffer.length); // initialize datagram request
            while(true){    // loop forever
                aSocket.receive(request);   // capture incoming request datagram

                // change sizing of request byte array to build string correctly
                byte[] requestBytes = new byte[request.getLength()];    // initialize byte array with request length
                int j = 0;  // demo int to iterate over
                for (int i = 0; i < requestBytes.length; i++) {
                    requestBytes[i] = request.getData()[j];     // copy each request byte into new byte array until request length is met
                    j++;
                }

                int clientNum = Integer.parseInt(new String(requestBytes)); // convert request bytes into a string, then to a number
                arithmetic(clientNum);  // pass client number to arithmetic method
                String replyString = String.valueOf(sum);   // convert arithmetic method return value to string
                byte[] m = replyString.getBytes();  // create byte array from string value of sum

                DatagramPacket reply = new DatagramPacket(m, m.length, request.getAddress(), request.getPort()); // initialize reply datagram
                System.out.println("Returning sum of " + sum + " to client"); // print string built from request byte data
                aSocket.send(reply);    // issue datagram packet reply through socket

            }

        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());     // catch SocketException
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());    // catch IOException
        }finally {if(aSocket != null) aSocket.close();}     // close socket
    }
}
