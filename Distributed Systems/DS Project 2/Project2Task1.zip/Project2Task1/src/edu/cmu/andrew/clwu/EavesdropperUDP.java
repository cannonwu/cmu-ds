package edu.cmu.andrew.clwu;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

/**
 * Deploy proxy server that will intercept communications between client and EchoServer.
 * Eavesdropper server will communicate across server port and client port.
 */
public class EavesdropperUDP {
    public static void main(String args[]){
        System.out.println("Eavesdropper running");  // announce eavesdropper startup
        // prompt user for port number inputs
        Scanner input = new Scanner(System.in);
        System.out.println("Enter listening port:");
        int listenPort = input.nextInt();
        System.out.println("Enter masquerade port:");
        int serverPort = input.nextInt();

        DatagramSocket listenSocket = null;      // initialize listen datagram socket
        DatagramSocket forwardSocket = null;     // initialize forward datagram socket
        byte[] buffer = new byte[1000];     // initialize buffer byte array to hold incoming byte data
        try{    // surround datagram receiving and replying process in try/catch block
            InetAddress aHost = InetAddress.getByName("localhost"); // set client ip address to localhost
            listenSocket = new DatagramSocket(listenPort); // assign socket to listen on this port number
            while(true){    // loop forever
//-------------- INTERCEPT CLIENT REQUEST & FORWARD A REQUEST CLONE TO SERVER --------------------------------
                DatagramPacket request = new DatagramPacket(buffer, buffer.length); // initialize datagram request

                listenSocket.receive(request);   // capture incoming request datagram
                DatagramPacket requestClone = new DatagramPacket(request.getData(),
                        request.getLength(), aHost, serverPort); // clone the client request and insert correct server port

                // change sizing of request byte array to build string correctly
                byte[] requestBytes = new byte[request.getLength()];    // initialize byte array with request length
                int j = 0;  // demo int to iterate over
                for (int i = 0; i < requestBytes.length; i++) {
                    requestBytes[i] = request.getData()[j];     // copy each request byte into new byte array until request length is met
                    j++;
                }
                String requestString = new String(requestBytes); // build string from request byte data
                System.out.println("Client request: "+requestString); // print string built from request byte data

                forwardSocket = new DatagramSocket();   // create new forwarding socket
                forwardSocket.send(requestClone);    // forward the clone of the client request to the server
//-------------- CAPTURE SERVER REPLY & FORWARD A REPLY CLONE TO SERVER --------------------------------------
                DatagramPacket reply = new DatagramPacket(buffer, buffer.length);

                forwardSocket.receive(reply);   // capture incoming request datagram
                DatagramPacket replyClone = new DatagramPacket(reply.getData(),
                        reply.getLength(), request.getAddress(), request.getPort()); // clone the server reply and correct client port

                // change sizing of request byte array to build string correctly
                byte[] replyBytes = new byte[reply.getLength()];    // initialize byte array with request length
                int k = 0;  // demo int to iterate over
                for (int i = 0; i < replyBytes.length; i++) {
                    replyBytes[i] = reply.getData()[k];     // copy each request byte into new byte array until request length is met
                    k++;
                }

                String replyString = new String(replyBytes); // build string from request byte data
                System.out.println("Server reply: "+replyString); // print string built from request byte data

                listenSocket.send(replyClone);    // forward the clone of the client request to the server
            }

        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());     // catch SocketException
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());    // catch IOException
        }finally {if(listenSocket != null) listenSocket.close();
                  if (forwardSocket != null) forwardSocket.close();}     // close sockets

    }
}
