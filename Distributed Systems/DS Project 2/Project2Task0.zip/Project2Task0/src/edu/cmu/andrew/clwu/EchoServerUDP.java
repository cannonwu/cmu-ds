package edu.cmu.andrew.clwu;

import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 *
 */
public class EchoServerUDP {
    public static void main(String args[]){
        System.out.println("The server is running."); // announce startup

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        DatagramSocket aSocket = null;      // initialize datagram socket
        byte[] buffer = new byte[1000];     // initialize buffer byte array to hold incoming byte data
        try{    // surround datagram receiving and replying process in try/catch block
            aSocket = new DatagramSocket(portNum); // assign socket to listen on this port number
            DatagramPacket request = new DatagramPacket(buffer, buffer.length); // initialize datagram request
            while(true){    // loop forever
                aSocket.receive(request);   // capture incoming request datagram
                DatagramPacket reply = new DatagramPacket(request.getData(),
                        request.getLength(), request.getAddress(), request.getPort()); // initialize reply datagram which echoes request datagram data

                // change sizing of request byte array to build string correctly
                byte[] requestBytes = new byte[request.getLength()];    // initialize byte array with request length
                int j = 0;  // demo int to iterate over
                for (int i = 0; i < requestBytes.length; i++) {
                    requestBytes[i] = request.getData()[j];     // copy each request byte into new byte array until request length is met
                    j++;
                }

                String requestString = new String(requestBytes); // build string from request byte data
                System.out.println("Echoing: "+requestString); // print string built from request byte data
                aSocket.send(reply);    // issue datagram packet reply through socket

                //handle user quit/halt command
                if (requestString.equals("halt!")) {
                    System.out.println("Server side quitting");
                    break;
                }
            }

        }catch (SocketException e){System.out.println("Socket: " + e.getMessage());     // catch SocketException
        }catch (IOException e) {System.out.println("IO: " + e.getMessage());    // catch IOException
        }finally {if(aSocket != null) aSocket.close();}     // close socket
    }
}
