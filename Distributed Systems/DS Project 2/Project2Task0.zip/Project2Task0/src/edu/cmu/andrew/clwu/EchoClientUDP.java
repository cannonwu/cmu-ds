package edu.cmu.andrew.clwu;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class EchoClientUDP {
    public static void main(String args[]){
        System.out.println("The client is running."); // announce startup

        // Prompt user for server side port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        // args give message contents and server hostname
        DatagramSocket aSocket = null;  // initialize datagram socket
        try {   // surround datagram request process with try/catch block
            InetAddress aHost = InetAddress.getByName("localhost"); // set client ip address to localhost
            int serverPort = portNum;  // set server side number port to portNum: 6789
            aSocket = new DatagramSocket(); // instantiate new socket
            String nextLine; // instantiate user line to be read
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));    // capture client input stream
            while ((nextLine = typed.readLine()) != null) { // read entire client input stream
                byte [] m = nextLine.getBytes(); // encode line of client input into a byte array
                DatagramPacket request = new DatagramPacket(m,  m.length, aHost, serverPort); // create datagram request packet of one line
                aSocket.send(request); // issue datagram request through socket
                byte[] buffer = new byte[1000]; // initialize byte array to hold incoming server reply data
                DatagramPacket reply = new DatagramPacket(buffer, buffer.length); // initialize server reply datagram packet
                aSocket.receive(reply); // set reply to incoming datagram packet, which is an echo of each line of the client request

                // change sizing of request byte array to build string correctly
                byte[] replyBytes = new byte[reply.getLength()];    // initialize byte array with reply length
                int j = 0;  // demo int to iterate over
                for (int i = 0; i < replyBytes.length; i++) {
                    replyBytes[i] = reply.getData()[j];     // copy each reply byte into new byte array until reply length is met
                    j++;
                }

                System.out.println("Reply: " + new String(replyBytes));    // print reply string built from datagram

                // handle user quit/halt command
                if (new String(replyBytes).equals("halt!")) {
                    System.out.println("Client side quitting");
                    break;
                }
            }

        }catch (SocketException e) {System.out.println("Socket: " + e.getMessage());    // catch socket exception
        }catch (IOException e){System.out.println("IO: " + e.getMessage());     // catch IOException
        }finally {if(aSocket != null) aSocket.close();}  // close socket
    }
}
