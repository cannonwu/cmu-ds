// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

import com.google.gson.Gson;

import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Client {

    static int serverPort = 0;
    static Socket clientSocket = null;

    /**
     * Open the TCP Socket with user-provided server port.
     */
    public static void openSocket(){
        // arguments supply hostname
        try {
            // set up connection and stream pipeline
            clientSocket = new Socket("localhost", serverPort);
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }
    }

    /**
     * Build JSON requests based on user menu selection.
     * Write/Receive data from the TCP socket.
     * @param menuSelection
     */
    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static void callServer(int menuSelection) {
        RequestMessage reqm = new RequestMessage();

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            // 0. View basic blockchain status.
            if (menuSelection == 0) {
                // Send message over TCP and convert JSON response into separate strings for displaying blockchain size,
                // latest block difficulty, total chain difficulty, hashesPerSecond, totalExpectedHashes for the chain,
                // latest block nonce, and chainHash

                // send json text to the stream
                String request = reqm.viewStatusRequest();
                out.println(request);   // call RequestMessage.addRequest() to build JSON request message
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);

                // size, latestDiff, totalDiff, hashesPerSecond, nonce were converted to double by JSON/GSON
                // store each of these in a double var to be converted to int during printing
                Double size = (Double) responseMap.get("size");
                Double latestDiff = (Double) responseMap.get("latestDiff");
                Double totalDiff = (Double) responseMap.get("totalDiff");
                Double hashesPerSecond = (Double) responseMap.get("hashesPerSecond");
                Double nonce = (Double) responseMap.get("nonce");

                // Print JSON response
                System.out.println("Current size of chain: " + size.intValue());
                System.out.println("Difficulty of most recent block: " + latestDiff.intValue());
                System.out.println("Total difficulty for all blocks: " + totalDiff.intValue());
                System.out.println("Approximate hashes per second on this machine: " + hashesPerSecond.intValue());
                System.out.println("Expected total hashes required for the whole chain: " + responseMap.get("totalExpectedHashes"));
                System.out.println("Nonce for most recent block: " + nonce.intValue());
                System.out.println("Chain hash: " + responseMap.get("chainHash"));

            }

            // 1. Add a transaction to the blockchain.
            if (menuSelection == 1) {
                // get difficulty
                Scanner input = new Scanner(System.in);
                System.out.println("Enter difficulty > 0");
                int difficulty = input.nextInt();
                input.nextLine(); // clear Scanner
                // get transaction data
                System.out.println("Enter transaction");
                String data = input.nextLine();

                // send json text to the stream
                String request = reqm.addRequest(difficulty, data);
                out.println(request);   // call RequestMessage.addRequest() to build JSON request message
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);

                // From Map, get: response = duration of execution
                System.out.println(responseMap.get("response"));
            }

            // 2. Verify the blockchain.
            if (menuSelection == 2) {
                // Call isChainValid and time the duration of the routine
                // send json text to the stream
                String request = reqm.verifyRequest();
                out.println(request);
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);
                // Print server data to console
                System.out.println(responseMap.get("response").toString().replace(",","\n"));
                System.out.println(responseMap.get("durationReport"));
            }

            // 3. View the blockchain.
            if (menuSelection == 3) {
                // Call blockchain's overridden toString method
                // send json text to the stream
                String request = reqm.viewChainRequest();
                out.println(request);
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);

                // Print server returned info to console
                System.out.print("{ \"ds_chain\" : [ ");
                ArrayList blockArray = (ArrayList) responseMap.get("ds_chain");
                for (int i = 0; i < blockArray.size(); i++) {
                    System.out.println(blockArray.get(i));
                }
                System.out.print("], \"chainHash\":\"");
                System.out.print(responseMap.get("chainHash"));
                System.out.println("\"}");

            }

            // 4. Corrupt the chain.
            if (menuSelection == 4) {
                // Get user's corruption data
                Scanner input = new Scanner(System.in);
                System.out.println("Enter block ID of block to corrupt");
                int corruptIndex = input.nextInt();
                System.out.println("Enter new data for block " + corruptIndex);
                input.nextLine(); // clear scanner buffer
                String corruptData = input.nextLine();

                // Set corrupt data
                String request = reqm.corruptRequest(corruptIndex, corruptData);

                // Send request
                out.println(request);
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);
                System.out.println(responseMap.get("response"));
            }

            // 5. Hide the corruption by repairing the chain.
            if (menuSelection == 5) {
                // Call repairChain request
                // send json text to the stream
                String request = reqm.repairRequest();
                out.println(request);
                out.flush();

                // Receive response, convert from json to map class
                String responseString = in.readLine();
                Gson gson = new Gson();
                Map responseMap = gson.fromJson(responseString, Map.class);
                System.out.println(responseMap.get("response"));
            }

        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }
    }


    /**
     * Displays menu and calls server communication methods.
     * @param args
     */
    public static void main(String args[]) {
        System.out.println("The client is running."); // announce startup

        // get port number
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        serverPort = input.nextInt();
        System.out.println();

        // open socket
        openSocket();

        // get user value inputs and loop forever
        while (true) {      // loop forever
            // print menu to console
            System.out.println("0. View basic blockchain status.");
            System.out.println("1. Add a transaction to the blockchain.");
            System.out.println("2. Verify the blockchain.");
            System.out.println("3. View the blockchain.");
            System.out.println("4. Corrupt the chain.");
            System.out.println("5. Hide the corruption by repairing the chain.");
            System.out.println("6. Exit.");
            input = new Scanner(System.in);
            int menuSelection = input.nextInt();

            // if user selects 6, break, else serve request
            if (menuSelection == 6) {
                break;
            } else {
                callServer(menuSelection);
            }

        }

        System.out.println("Client side quitting. The server is still running.");

        try {
            if (clientSocket != null) {
                clientSocket.close();
            }
        } catch (IOException e) {
            // ignore exception on close
        }

    }
}
