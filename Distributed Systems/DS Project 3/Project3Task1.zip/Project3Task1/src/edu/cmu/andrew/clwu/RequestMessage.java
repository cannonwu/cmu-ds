// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

/**
 * Encapsulate all server request messages that will be written to the socket.
 * All messages are built as JSON string representations.
 * Request types are indicated by method name.
 */
public class RequestMessage {
    // Client calls request by selection 0
    public String viewStatusRequest() {
        // build request string as JSON representation
        String request = "{\"selection\":" + 0 + "}";
        return request;
    }

    // Client calls request by selection 1
    public String addRequest(int difficulty, String data) {
        // build request string as JSON representation
        String request =
                "{\"selection\":" + 1 + "," +
                "\"difficulty\":" + difficulty + "," +
                "\"data\":\"" + data + "\"}";
        return request;
    }

    // Client calls request by selection 2
    public String verifyRequest() {
        // build request string as JSON representation
        String request = "{\"selection\":" + 2 + "}";
        return request;
    }

    // Client calls request by selection 3
    public String viewChainRequest() {
        // build request string as JSON representation
        String request = "{\"selection\":" + 3 + "}";
        return request;
    }

    // Client calls request by selection 4
    public String corruptRequest(int corruptIndex, String corruptData) {
        // build request string as JSON representation
        String request =
                "{\"selection\":" + 4 + "," +
                "\"corruptIndex\":" + corruptIndex + "," +
                "\"corruptData\":\"" + corruptData + "\"}";
        return request;
    }

    // Client calls request by selection 5
    public String repairRequest() {
        // build request string as JSON representation
        String request = "{\"selection\":" + 5 + "}";
        return request;
    }
}
