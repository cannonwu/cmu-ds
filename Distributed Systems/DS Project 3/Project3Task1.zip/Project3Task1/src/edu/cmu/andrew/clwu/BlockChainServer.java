// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

import com.google.gson.Gson;

public class BlockChainServer {
    // 3 instance members
    ArrayList<Block> blockChain;
    String chainHash; // the hash of the most recent block in the chain
    int hashesPerSecond;

    /**
     * BlockChain constructor
     */
    public BlockChainServer() {
        blockChain = new ArrayList<>();     // initialize blockChain
        chainHash = "";     // initialize chainHash to blank string for genesis block, updated on each addBlock() call
        hashesPerSecond = 0;    // initialize hashesPerSecond for system performance calculations
    }

    /**
     * Simple getter for chainHash.
     * @return chainHash
     */
    public String getChainHash() {
        return chainHash;
    }

    /**
     * Simple getter for current system time.
     * @return current system time.
     */
    public Timestamp getTime() {
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        return currentTime;
    }

    /**
     * Simple getter for latest block added to the chain
     * @return get last block in the blockchain
     */
    public Block getLatestBlock() {
        return blockChain.get(blockChain.size() - 1);   // return last Block element in ArrayList
    }

    /**
     * Simple getter for number of blocks in blockchain
     * @return block chain size
     */
    public int getChainSize() {
        return blockChain.size();
    }

    /**
     * Calculate system performance regarding hashes computed per second.
     * Time duration of hashing simple string 2 million times.
     * @throws NoSuchAlgorithmException
     */
    public void computeHashesPerSecond() throws NoSuchAlgorithmException {
        long start = System.currentTimeMillis();
        for (int i = 0; i < 2000000; i++) {     // compute hash 2 million times
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update("00000000".getBytes());    // hash simple string with SHA-256
        }
        long stop = System.currentTimeMillis();
        double computeTime = (double) (stop - start) / 1000;     // calculate total duration
        hashesPerSecond = (int) ( 2000000 / computeTime);    // calculate hashesPerSecond
    }

    /**
     * Simple getter for calculated hashesPerSecond.
     * @return hashesPerSecond
     */
    public int getHashesPerSecond() {
        return hashesPerSecond;
    }

    /**
     * Add the passed in block to the blockchain.
     * Update chainHash with hash of the newly added block.
     * @param newBlock
     * @throws NoSuchAlgorithmException
     */
    public void addBlock(Block newBlock) throws NoSuchAlgorithmException {
        // store hash of newBlock in chainHash
        // this becomes prevHash for next block
        chainHash = newBlock.proofOfWork();
        blockChain.add(newBlock);       // add newBlock to the blockchain
    }

    /**
     * Iterate through the blockchain and call each Block's toString method.
     * Format all block data and chainHash into JSON.
     * @return JSON representation of the entire blockchain.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();     // initialize StringBuilder to store blockchain JSON representation
        sb.append("{ \"ds_chain\" : [ ");

        // if blockChain contains more than genesis block
        if (blockChain.size() > 1) {
            // iterate thru all blocks except the last one because of different formatting
            for (int i = 0; i < blockChain.size() - 1; i++) {
                sb.append(blockChain.get(i).toString());
                sb.append(",\n");
            }
        }

        sb.append(getLatestBlock().toString()); // append last block in blockchain
        sb.append("\n], \"chainHash\":\"");    // append chainHash value
        sb.append(chainHash);
        sb.append("\"}");
        return sb.toString();
    }

    /**
     * Simple getter for block at a given index.
     * @param i - block index
     * @return a block at index i in the blockchain
     */
    public Block getBlock(int i) {
        return blockChain.get(i);
    }

    /**
     * Calculate the total difficulty of the blockchain.
     * @return sum of difficulties of each block in the chain.
     */
    public int getTotalDifficulty() {
        int totalDifficulty = 0;
        for (Block b : blockChain) {
            totalDifficulty += b.getDifficulty();
        }
        return totalDifficulty;
    }

    /**
     * Calculate the total number of expected hashes that would be needed to find the hash of each block.
     * @return calculated expected hashes
     */
    public double getTotalExpectedHashes() {
        double totalExpectedHashes = 0;
        for (Block b : blockChain) {
            // calculate 1/16^(difficulty) for each block, then take inverse with exponentiation by -1
            // increment totalExpectedHashes by calculated inverse
            totalExpectedHashes += Math.pow( (Math.pow( (double) 1/16, b.getDifficulty() ) ) , -1);
        }
        return  totalExpectedHashes;
    }

    /**
     * Determines whether the chain is valid with different routines for chain size.
     * Routine for chain size = 1: check if genesis block hash is valid, if chainHash matches genesis hash.
     * Routine for chain size > 1: check block hash, hash pointer, and chainHash.
     * @return Pass or appropriate error message
     * @throws NoSuchAlgorithmException
     */
    public String isChainValid() throws NoSuchAlgorithmException {

        //-- If blockChain only holds genesis block
        if (blockChain.size() == 1) {
            StringBuilder proof = new StringBuilder();
            Block genesis = blockChain.get(0);
            for (int i = 0; i < genesis.getDifficulty(); i++) {
                // store number of leading zeros needed for proof of work based on block difficulty
                proof.append("0");
            }
            // if beginning substring of genesis hash does not equal expected string of leading 0's
            if ( !( genesis.calculateHash().substring(0, genesis.getDifficulty()).equals(proof.toString()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + genesis.getIndex()
                        + " Does not begin with " + proof;
            }
            // if chainHash does not equal genesis block hash
            if ( !( chainHash.equals(genesis.calculateHash()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + genesis.getIndex()
                        + " Does not match chainHash";
            }

        } else { // If blockChain holds more than genesis block
            // iterate thru blockChain, start with block 1, check if prevHash matches -1 index hash
            // check current block's proof of work (00...)
            // at the end check chainHash and final block's hash for match
            for (int i = 0; i < blockChain.size() - 1; i++) {
                StringBuilder proof = new StringBuilder();
                for (int j = 0; j < blockChain.get(i).getDifficulty(); j++) {
                    proof.append("0");      // store number of zeros needed for proof of work based on block difficulty
                }
                // if beginning substring of block's hash does not equal expected string based on block difficulty
                if ( !( blockChain.get(i).calculateHash().substring(0,
                        blockChain.get(i).getDifficulty()).equals(proof.toString()) ) ) {
                    // create and return error message
                    return "Chain verification: FALSE\nImproper hash on node " + blockChain.get(i).getIndex()
                            + " Does not begin with " + proof;
                }

                // if current block's hash does not match next block's hash pointer
                if ( !(blockChain.get(i).calculateHash().equals(blockChain.get(i+1).previousHash)) ) {
                    // create and return error message
                    return "Chain verification: FALSE\nImproper hash on node " + blockChain.get(i).getIndex()
                            + " Does not match next block's prevHash";
                }
            }

            // if chainHash does not equal latest block hash
            if ( !( chainHash.equals(getLatestBlock().calculateHash()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + getLatestBlock().getIndex()
                        + " Does not match chainHash";
            }
        }

        // if program makes it to this line, then chain is valid
        return "Chain verification: TRUE";
    }

    /**
     * Repair blockchain by recomputing proof of work for each block in the chain.
     * First, check the hashes of each block and ensure illegal hashes are recomputed.
     * If illegal hashes are actually present, recompute each block's hash.
     * Then, replace old blockchain blocks with repaired blocks.
     * @throws NoSuchAlgorithmException
     */
    public void repairChain() throws NoSuchAlgorithmException {
        boolean invalidChain = false; // flag for invalid chain

        // iterate thru each block
        for (int i = 0; i < blockChain.size() - 1; i++) {
            // check for invalid hash pointer
            if (! blockChain.get(i).calculateHash().equals(blockChain.get(i+1).previousHash) ) {
                invalidChain = true;    // set invalid chain flag to true
                break;
            }
        }

        // if latest block hash does not equal chainHash, then chain is invalid
        if (! blockChain.get(getLatestBlock().index).calculateHash().equals(chainHash)) {
            invalidChain = true;    // set invalid chain flag to true
        }

        // if any block's hash is found to be invalid, then entire chain must be recomputed
        if (invalidChain) {
            ArrayList<Block> repairChain = new ArrayList<>();   // initialize a repair chain branch
            chainHash = "";  // reset chainHash to blank string

            // iterate thru each block in the original chain
            for (int i = 0; i < blockChain.size(); i++) {
                // initialize newBlock with current block's data
                Block newBlock = new Block(blockChain.get(i).getIndex(), blockChain.get(i).getTimestamp(),
                        blockChain.get(i).getData(), blockChain.get(i).getDifficulty());
                newBlock.setPreviousHash(chainHash);     // set previous hash to the current chainHash
                repairChain.add(newBlock);  // add block to repairChain
                // store hash of newBlock in chainHash, this becomes prevHash for next block
                chainHash = newBlock.proofOfWork(); // update chainHash
            }

            blockChain.clear();     // clear blockChain of old blocks
            blockChain.addAll(repairChain);     // update blockChain with repairChain blocks
        }
    }

    /**
     * Main driver displays menu and parses user input.
     * On startup, it creates blockchain with genesis block and computes hashesPerSecond.
     * Handles user input by calling the appropriate methods as defined by the user.
     * @param args
     * @throws NoSuchAlgorithmException
     */
    // Code from Coulouris, G. F., Dollimore, J., & Kindberg, T. (2012). Distributed systems: Concepts and design. Addison-Wesley.
    public static void main(String[] args) throws NoSuchAlgorithmException {
        System.out.println("Blockchain server is running."); // announce startup

        BlockChainServer bc = new BlockChainServer();   // initialize a BlockChain object
        Block genesis = new Block(0, bc.getTime(), "Genesis", 2);   // create genesis block
        genesis.setPreviousHash(bc.chainHash);  // set genesis prevHash to empty string
        bc.addBlock(genesis);   // add genesis block to blockchain, also updates chainHash
        bc.computeHashesPerSecond();    // establish hashesPerSecond instance member

        int index = 0; // initialize an index to be used for adding a transaction to the blockchain

        // prompt user for the port number for server to listen on
        Scanner input = new Scanner(System.in);
        System.out.println("Enter port number:");
        int portNum = input.nextInt();

        ResponseMessage respm = new ResponseMessage(); // initialize response message class

        // --INITIALIZE TCP COMMUNICATIONS-- //
        Socket clientSocket = null;
        try {
            // Create a new server socket
            ServerSocket listenSocket = new ServerSocket(portNum);

            /*
             * Forever,
             *   read a line from the socket
             *   print it to the console
             *   echo it (i.e. write it) back to the client
             */
            while (true) {
                /*
                 * Block waiting for a new connection request from a client.
                 * When the request is received, "accept" it, and the rest
                 * the tcp protocol handshake will then take place, making
                 * the socket ready for reading and writing.
                 */
                clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                System.out.println("We have a visitor");

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

                // Forever receive data over TCP socket
                while (in.hasNext()) {
                    String clientString = in.nextLine();

                    // convert clientString back to json
                    Gson gson = new Gson();
                    Map requestMap = gson.fromJson(clientString, Map.class);

                    // get client selection from json data.
                    // JSON/GSON had converted selection int to double but it doesn't matter here.
                    double selection = (double) requestMap.get("selection");

                    // 0. View basic blockchain status.
                    if (selection == 0) {
                        // Call methods to display blockchain size, latest block difficulty, total chain difficulty, hashesPerSecond,
                        // totalExpectedHashes for the chain, latest block nonce, and chainHash

                        // call methods and pass to ResponseMessage class, convert to string when writing to socket
                        String response = respm.viewStatusResponse(bc.blockChain.size(), bc.getLatestBlock().getDifficulty(),
                                bc.getTotalDifficulty(), bc.getHashesPerSecond(), bc.getTotalExpectedHashes(),
                                bc.getLatestBlock().getNonce(), bc.getChainHash());

                        out.println(response);
                        out.flush();

                        System.out.println("Response: " + response);
                    }

                    // 1. Add a transaction to the blockchain.
                    if (selection == 1) {
                        System.out.println("Adding a block");
                        Double difficulty = (Double) requestMap.get("difficulty");
                        String data = (String) requestMap.get("data");

                        long start = System.currentTimeMillis();
                        // initialize block passing user args and incremented index (++index)
                        Block newBlock = new Block(++index, bc.getTime(), data, difficulty.intValue());
                        newBlock.setPreviousHash(bc.chainHash);     // set previous hash to the current chainHash
                        bc.addBlock(newBlock);  // add block to blockchain, also updates chainHash
                        long stop = System.currentTimeMillis();
                        long duration = stop - start;

                        String durationReport = "Total execution time to add this block was " + duration + " milliseconds";
                        // build response string, print to socket
                        String response = respm.addBlockResponse(durationReport);
                        out.println(response);
                        out.flush();

                        System.out.println("Setting response to " + durationReport);
                        System.out.println("..." + response);
                    }

                    // 2. Verify the blockchain.
                    if (selection == 2) {
                        // Call isChainValid and time the duration of the routine
                        System.out.println("Verifying entire chain");
                        long start = System.currentTimeMillis();
                        String verification = bc.isChainValid().replace("\n",",");
                        long stop = System.currentTimeMillis();
                        // include necessary information in response message and print to socket
                        String durationReport = "Total execution time to verify the chain was " + (stop - start) + " milliseconds";
                        String response = respm.verifyChainResponse(verification, durationReport);
                        out.println(response);
                        out.flush();

                        // print to console
                        System.out.println(verification);  // print to server console
                        System.out.println(durationReport);

                    }

                    // 3. View the blockchain.
                    if (selection == 3) {
                        System.out.println("View the Blockchain");
                        // Call blockchain's overridden toString method
                        String viewChain = bc.toString();
                        String response = respm.viewChainResponse(viewChain);
                        out.println(response);
                        out.flush();

                        System.out.println("Setting response to " + bc.toString());

                    }

                    // 4. Corrupt the chain.
                    if (selection == 4) {
                        System.out.println("Corrupt the blockchain");
                        Double corruptIndex = (Double) requestMap.get("corruptIndex");
                        String corruptData = (String) requestMap.get("corruptData");

                        // Set corrupt data to user-requested block
                        bc.blockChain.get(corruptIndex.intValue()).setData(corruptData);
                        // Print to server console
                        System.out.println("Block " + corruptIndex.intValue() + " now holds " + corruptData);
                        // Build and send response
                        String response = respm.corruptDataResponse(corruptIndex,corruptData);
                        out.println(response);
                        out.flush();
                    }

                    // 5. Hide the corruption by repairing the chain.
                    if (selection == 5) {
                        System.out.println("Repairing the entire chain");
                        // Call repairChain method and time the duration of the routine.
                        long start = System.currentTimeMillis();
                        bc.repairChain();
                        long stop = System.currentTimeMillis();

                        // Build and send response
                        String response = respm.repairChainResponse(start, stop);
                        out.println(response);
                        out.flush();

                        // Print to server console
                        System.out.println("Total execution time to repair the chain was " + (stop - start) + " milliseconds");

                    }

                }
            }

            // Handle exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting (typically by you sending quit signal) clean up sockets
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }

    }

}
