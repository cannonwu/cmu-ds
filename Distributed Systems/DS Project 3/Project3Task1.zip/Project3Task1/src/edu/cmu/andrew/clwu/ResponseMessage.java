// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

import java.math.BigInteger;

/**
 * Encapsulate all server response messages that will be written to the socket.
 * All messages are built as JSON string representations.
 * Response types are indicated by method name.
 */
public class ResponseMessage {

    // Server calls response to selection 0
    public String viewStatusResponse(int size, int latestDiff, int totalDiff, int hashesPerSecond,
                                         double totalExpectedHashes, BigInteger nonce, String chainHash) {
        // build response string as JSON representation
        String response =
                "{\"selection\":" + 0 + "," +
                "\"size\":" + size + "," +
                "\"latestDiff\":" + latestDiff + "," +
                "\"totalDiff\":" + totalDiff + "," +
                "\"hashesPerSecond\":" + hashesPerSecond + "," +
                "\"totalExpectedHashes\":" + totalExpectedHashes + "," +
                "\"nonce\":" + nonce + "," +
                "\"chainHash\":\"" + chainHash + "\"}";
        return response;
    }

    // Server calls response to selection 1
    public String addBlockResponse(String durationReport) {
        // build response string as JSON representation
        String response =
                "{\"selection\":" + 1 + "," +
                "\"response\":\"" + durationReport + "\"}";
        return response;
    }

    // Server calls response to selection 2
    public String verifyChainResponse(String verifyResult, String durationReport) {
        // build response string as JSON representation
        String response =
                "{\"selection\":" + 2 + "," +
                "\"response\":\"" + verifyResult + "\"" + "," +
                "\"durationReport\":\"" + durationReport + "\"}";
        return response;
    }

    // Server calls response to selection 3
    public String viewChainResponse(String viewChain) {
        // build response string as JSON representation
        String response = viewChain.replace("\n", "");
        return response;
    }

    // Server calls response to selection 4
    public String corruptDataResponse(double corruptIndex, String corruptData) {
        // build response string as JSON representation
        String response =
                "{\"selection\":" + 4 + "," +
                "\"response\":\"" + "Block " + corruptIndex + " now holds " + corruptData + "\"}";
        return response;
    }

    // Server calls response to selection 5
    public String repairChainResponse(long start, long stop) {
        // build response string as JSON representation
        String response =
                "{\"selection\":" + 5 + "," +
                "\"response\":\"" + "Total execution time to repair the chain was " + (stop - start) + " milliseconds" + "\"}";
        return response;
    }

}
