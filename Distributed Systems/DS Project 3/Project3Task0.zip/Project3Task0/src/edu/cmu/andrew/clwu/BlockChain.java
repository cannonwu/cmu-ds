// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

public class BlockChain {
    // 3 instance members
    ArrayList<Block> blockChain;
    String chainHash; // the hash of the most recent block in the chain
    int hashesPerSecond;

    /**
     * BlockChain constructor
     */
    public BlockChain() {
        blockChain = new ArrayList<>();     // initialize blockChain
        chainHash = "";     // initialize chainHash to blank string for genesis block, updated on each addBlock() call
        hashesPerSecond = 0;    // initialize hashesPerSecond for system performance calculations
    }

    /**
     * Simple getter for chainHash.
     * @return chainHash
     */
    public String getChainHash() {
        return chainHash;
    }

    /**
     * Simple getter for current system time.
     * @return current system time.
     */
    public Timestamp getTime() {
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        return currentTime;
    }

    /**
     * Simple getter for latest block added to the chain
     * @return get last block in the blockchain
     */
    public Block getLatestBlock() {
        return blockChain.get(blockChain.size() - 1);   // return last Block element in ArrayList
    }

    /**
     * Simple getter for number of blocks in blockchain
     * @return block chain size
     */
    public int getChainSize() {
        return blockChain.size();
    }

    /**
     * Calculate system performance regarding hashes computed per second.
     * Time duration of hashing simple string 2 million times.
     * @throws NoSuchAlgorithmException
     */
    public void computeHashesPerSecond() throws NoSuchAlgorithmException {
        long start = System.currentTimeMillis();
        for (int i = 0; i < 2000000; i++) {     // compute hash 2 million times
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update("00000000".getBytes());    // hash simple string with SHA-256
        }
        long stop = System.currentTimeMillis();
        double computeTime = (double) (stop - start) / 1000;     // calculate total duration
        hashesPerSecond = (int) ( 2000000 / computeTime);    // calculate hashesPerSecond
    }

    /**
     * Simple getter for calculated hashesPerSecond.
     * @return hashesPerSecond
     */
    public int getHashesPerSecond() {
        return hashesPerSecond;
    }

    /**
     * Add the passed in block to the blockchain.
     * Update chainHash with hash of the newly added block.
     * @param newBlock
     * @throws NoSuchAlgorithmException
     */
    public void addBlock(Block newBlock) throws NoSuchAlgorithmException {
        // store hash of newBlock in chainHash
        // this becomes prevHash for next block
        chainHash = newBlock.proofOfWork();
        blockChain.add(newBlock);       // add newBlock to the blockchain
    }

    /**
     * Iterate through the blockchain and call each Block's toString method.
     * Format all block data and chainHash into JSON.
     * @return JSON representation of the entire blockchain.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();     // initialize StringBuilder to store blockchain JSON representation
        sb.append("{\"ds_chain\" : [ ");

        // if blockChain contains more than genesis block
        if (blockChain.size() > 1) {
            // iterate thru all blocks except the last one because of different formatting
            for (int i = 0; i < blockChain.size() - 1; i++) {
                sb.append(blockChain.get(i).toString());
                sb.append(",\n");
            }
        }

        sb.append(getLatestBlock().toString()); // append last block in blockchain
        sb.append("\n ], \"chainHash\":\"");    // append chainHash value
        sb.append(chainHash);
        sb.append("\"}");
        return sb.toString();
    }

    /**
     * Simple getter for block at a given index.
     * @param i - block index
     * @return a block at index i in the blockchain
     */
    public Block getBlock(int i) {
        return blockChain.get(i);
    }

    /**
     * Calculate the total difficulty of the blockchain.
     * @return sum of difficulties of each block in the chain.
     */
    public int getTotalDifficulty() {
        int totalDifficulty = 0;
        for (Block b : blockChain) {
            totalDifficulty += b.getDifficulty();
        }
        return totalDifficulty;
    }

    /**
     * Calculate the total number of expected hashes that would be needed to find the hash of each block.
     * @return calculated expected hashes
     */
    public double getTotalExpectedHashes() {
        double totalExpectedHashes = 0;
        for (Block b : blockChain) {
            // calculate 1/16^(difficulty) for each block, then take inverse with exponentiation by -1
            // increment totalExpectedHashes by calculated inverse
            totalExpectedHashes += Math.pow( (Math.pow( (double) 1/16, b.getDifficulty() ) ) , -1);
        }
        return  totalExpectedHashes;
    }

    /**
     * Determines whether the chain is valid with different routines for chain size.
     * Routine for chain size = 1: check if genesis block hash is valid, if chainHash matches genesis hash.
     * Routine for chain size > 1: check block hash, hash pointer, and chainHash.
     * @return Pass or appropriate error message
     * @throws NoSuchAlgorithmException
     */
    public String isChainValid() throws NoSuchAlgorithmException {

        //-- If blockChain only holds genesis block
        if (blockChain.size() == 1) {
            StringBuilder proof = new StringBuilder();
            Block genesis = blockChain.get(0);
            for (int i = 0; i < genesis.getDifficulty(); i++) {
                // store number of leading zeros needed for proof of work based on block difficulty
                proof.append("0");
            }
            // if beginning substring of genesis hash does not equal expected string of leading 0's
            if ( !( genesis.calculateHash().substring(0, genesis.getDifficulty()).equals(proof.toString()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + genesis.getIndex()
                        + " Does not begin with " + proof;
            }
            // if chainHash does not equal genesis block hash
            if ( !( chainHash.equals(genesis.calculateHash()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + genesis.getIndex()
                        + " Does not match chainHash";
            }

        } else { // If blockChain holds more than genesis block
            // iterate thru blockChain, start with block 1, check if prevHash matches -1 index hash
            // check current block's proof of work (00...)
            // at the end check chainHash and final block's hash for match
            for (int i = 0; i < blockChain.size() - 1; i++) {
                StringBuilder proof = new StringBuilder();
                for (int j = 0; j < blockChain.get(i).getDifficulty(); j++) {
                    proof.append("0");      // store number of zeros needed for proof of work based on block difficulty
                }
                // if beginning substring of block's hash does not equal expected string based on block difficulty
                if ( !( blockChain.get(i).calculateHash().substring(0,
                        blockChain.get(i).getDifficulty()).equals(proof.toString()) ) ) {
                    // create and return error message
                    return "Chain verification: FALSE\nImproper hash on node " + blockChain.get(i).getIndex()
                            + " Does not begin with " + proof;
                }

                // if current block's hash does not match next block's hash pointer
                if ( !(blockChain.get(i).calculateHash().equals(blockChain.get(i+1).previousHash)) ) {
                    // create and return error message
                    return "Chain verification: FALSE\nImproper hash on node " + blockChain.get(i).getIndex()
                            + " Does not match next block's prevHash";
                }
            }

            // if chainHash does not equal latest block hash
            if ( !( chainHash.equals(getLatestBlock().calculateHash()) ) ) {
                // create and return error message
                return "Chain verification: FALSE\nImproper hash on node " + getLatestBlock().getIndex()
                        + " Does not match chainHash";
            }
        }

        // if program makes it to this line, then chain is valid
        return "Chain verification: TRUE";
    }

    /**
     * Repair blockchain by recomputing proof of work for each block in the chain.
     * First, check the hashes of each block and ensure illegal hashes are recomputed.
     * If illegal hashes are actually present, recompute each block's hash.
     * Then, replace old blockchain blocks with repaired blocks.
     * @throws NoSuchAlgorithmException
     */
    public void repairChain() throws NoSuchAlgorithmException {
        boolean invalidChain = false; // flag for invalid chain

        // iterate thru each block
        for (int i = 0; i < blockChain.size() - 1; i++) {
            // check for invalid hash pointer
            if (! blockChain.get(i).calculateHash().equals(blockChain.get(i+1).previousHash) ) {
                invalidChain = true;    // set invalid chain flag to true
                break;
            }
        }

        // if latest block hash does not equal chainHash, then chain is invalid
        if (! blockChain.get(getLatestBlock().index).calculateHash().equals(chainHash)) {
            invalidChain = true;    // set invalid chain flag to true
        }

        // if any block's hash is found to be invalid, then entire chain must be recomputed
        if (invalidChain) {
            ArrayList<Block> repairChain = new ArrayList<>();   // initialize a repair chain branch
            chainHash = "";  // reset chainHash to blank string

            // iterate thru each block in the original chain
            for (int i = 0; i < blockChain.size(); i++) {
                // initialize newBlock with current block's data
                Block newBlock = new Block(blockChain.get(i).getIndex(), blockChain.get(i).getTimestamp(),
                        blockChain.get(i).getData(), blockChain.get(i).getDifficulty());
                newBlock.setPreviousHash(chainHash);     // set previous hash to the current chainHash
                repairChain.add(newBlock);  // add block to repairChain
                // store hash of newBlock in chainHash, this becomes prevHash for next block
                chainHash = newBlock.proofOfWork(); // update chainHash
            }

            blockChain.clear();     // clear blockChain of old blocks
            blockChain.addAll(repairChain);     // update blockChain with repairChain blocks
        }
    }

    /**
     * Main driver displays menu and parses user input.
     * On startup, it creates blockchain with genesis block and computes hashesPerSecond.
     * Handles user input by calling the appropriate methods as defined by the user.
     * @param args
     * @throws NoSuchAlgorithmException
     */
    public static void main(String[] args) throws NoSuchAlgorithmException {
        // Student Analysis:
        // As more blocks are added to the chain, addBlock() and chainRepair() will be slowed
        // because proofOfWork() will need to be called upon more blocks and compute proofOfWork() for each one.
        // Higher difficulty will also slow addBlock() and chainRepair() methods
        // because proofOfWork() will need to compute more hashes to find the corrected nonce as difficulty increases.
        // I used a difficulty of 6 for one transaction containing "somethingsomething" which took 14358 milliseconds
        // to compute proofOfWork(). Corrupting a different block in the same chain and executing repairChain() took
        // 16029 milliseconds. But, isChainValid() only took 0 milliseconds before and after repair.
        // isChainValid() is not affected by higher difficulty of blocks, for it only checks whether each block's
        // hash has the correct number of leading 0's, correct hash pointer, and whether the last block hash matches
        // the chainHash, as opposed to completely recomputing proofOfWork().
        // isChainValid() may be slightly affected by a great number of blocks in the chain
        // because more hashes will need to be computed and compared. Though, this will only make a very minute
        // difference especially with a small blockchain size.

        BlockChain bc = new BlockChain();   // initialize a BlockChain object
        Block genesis = new Block(0, bc.getTime(), "Genesis", 2);   // create genesis block
        genesis.setPreviousHash(bc.chainHash);  // set genesis prevHash to empty string
        bc.addBlock(genesis);   // add genesis block to blockchain, also updates chainHash
        bc.computeHashesPerSecond();    // establish hashesPerSecond instance member

        int index = 0; // initialize an index to be used for adding a transaction to the blockchain

        Scanner input;
        // Display Menu
        while (true) {
            System.out.println("0. View basic blockchain status.");
            System.out.println("1. Add a transaction to the blockchain.");
            System.out.println("2. Verify the blockchain.");
            System.out.println("3. View the blockchain.");
            System.out.println("4. Corrupt the chain.");
            System.out.println("5. Hide the corruption by repairing the chain.");
            System.out.println("6. Exit.");
            input = new Scanner(System.in);
            int menuSelection = input.nextInt();
            input.nextLine(); // clear Scanner

            // 0. View basic blockchain status.
            if (menuSelection == 0) {
                // Call methods to display blockchain size, latest block difficulty, total chain difficulty, hashesPerSecond,
                // totalExpectedHashes for the chain, latest block nonce, and chainHash
                System.out.println("Current size of chain: " + bc.blockChain.size());
                System.out.println("Difficulty of most recent block: " + bc.getLatestBlock().getDifficulty());
                System.out.println("Total difficulty for all blocks: " + bc.getTotalDifficulty());
                System.out.println("Approximate hashes per second on this machine: " + bc.getHashesPerSecond());
                System.out.println("Expected total hashes required for the whole chain: " + bc.getTotalExpectedHashes());
                System.out.println("Nonce for most recent block: " + bc.getLatestBlock().getNonce());
                System.out.println("Chain hash: " + bc.getChainHash());
            }

            // 1. Add a transaction to the blockchain.
            if (menuSelection == 1) {
                // get difficulty
                System.out.println("Enter difficulty > 0");
                int difficulty = input.nextInt();
                input.nextLine(); // clear Scanner
                // get transaction data
                System.out.println("Enter transaction");
                String data = input.nextLine();

                long start = System.currentTimeMillis();
                // initialize block passing user args and incremented index (++index)
                Block newBlock = new Block(++index, bc.getTime(), data, difficulty);
                newBlock.setPreviousHash(bc.chainHash);     // set previous hash to the current chainHash
                bc.addBlock(newBlock);  // add block to blockchain, also updates chainHash
                long stop = System.currentTimeMillis();
                System.out.println("Total execution time to add this block was " + (stop - start) + " milliseconds");
            }

            // 2. Verify the blockchain.
            if (menuSelection == 2) {
                // Call isChainValid and time the duration of the routine
                long start = System.currentTimeMillis();
                System.out.println(bc.isChainValid());
                long stop = System.currentTimeMillis();
                System.out.println("Total execution time to verify the chain was " + (stop - start) + " milliseconds");
            }

            // 3. View the blockchain.
            if (menuSelection == 3) {
                // Call blockchain's overridden toString method
                System.out.println(bc.toString());
            }

            // 4. Corrupt the chain.
            if (menuSelection == 4) {
                // Get user's corruption data
                System.out.println("Enter block ID of block to corrupt");
                int corruptIndex = input.nextInt();
                System.out.println("Enter new data for block " + corruptIndex);
                input.nextLine(); // clear scanner buffer
                String corruptData = input.nextLine();
                // Set corrupt data to user-requested block
                bc.blockChain.get(corruptIndex).setData(corruptData);
                System.out.println("Block " + corruptIndex + " now holds " + corruptData);
            }

            // 5. Hide the corruption by repairing the chain.
            if (menuSelection == 5) {
                // Call repairChain method and time the duration of the routine.
                long start = System.currentTimeMillis();
                bc.repairChain();
                long stop = System.currentTimeMillis();
                System.out.println("Total execution time to repair the chain was " + (stop - start) + " milliseconds");
            }

            // 6. Exit
            if (menuSelection == 6) {
                break;
            }

        }

    }

}
