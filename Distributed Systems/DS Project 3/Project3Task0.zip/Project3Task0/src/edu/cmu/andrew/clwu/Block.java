// Cannon Wu
// clwu@andrew.cmu.edu
package edu.cmu.andrew.clwu;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

public class Block {
    // Instance vars initialized by parameters given by user
    int index;
    Timestamp timestamp;
    String data;
    int difficulty;
    String previousHash;    // user passes blank string for genesis block

    BigInteger nonce;   // initialized in proofOfWork method

    /**
     * Block Constructor.
     * Passes client data as parameters.
     * @param index - the position of the block in the chain.
     * @param timestamp - time of block creation.
     * @param data - transaction string.
     * @param difficulty - user-defined leading 0 count.
     */
    public Block(int index, Timestamp timestamp, String data, int difficulty) {
        // Call setters for each parameter
        setIndex(index);
        setTimestamp(timestamp);
        setData(data);
        setDifficulty(difficulty);
    }

    /**
     * Quickly calculates hash of the block data.
     * @return hash of the block using stored block data.
     * @throws NoSuchAlgorithmException
     */
    // Code from https://github.com/CMU-Heinz-95702/Lab1-InstallationAndRaft
    public String calculateHash() throws NoSuchAlgorithmException {
        // concatenate block data with nonce and previousHash
        String blockData = index + String.valueOf(timestamp) + data + difficulty + nonce + previousHash;
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(blockData.getBytes());    // hash block data with SHA-256
        String hash = bytesToHex(md.digest());  // create string of hexadecimals from hash value
        return hash;
    }

    // Code from stack overflow
    // https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    // Returns a hex string given an array of bytes
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    /**
     * Simple getter for nonce.
     * @return Final calculated nonce.
     */
    public BigInteger getNonce() {
        return nonce;
    }

    /**
     * Create block hash according to the difficulty given by user.
     * Initializes nonce.
     * @return Good hash of the block. This will be used as prevHash in the next block.
     * @throws NoSuchAlgorithmException
     */
    public String proofOfWork() throws NoSuchAlgorithmException {
        nonce = new BigInteger("0");     // initialize nonce value
        int i = 0;  // initialize demo number to iterate over hash string
        String hash = null;     // initialize hash
        boolean foundNonce = false;     // initialize flag to indicate nonce found

        while (!foundNonce) {   // while nonce has not been found
            while (i < difficulty) {    // iterate over hash string indexes up to difficulty amount
                hash = calculateHash();     // calculate hash with updated nonce number
                if ( !(hash.charAt(i) == '0') ) {   // if char at string index within difficulty bounds is not 0
                    nonce = nonce.add(new BigInteger("1"));     // increment nonce
                    i = 0;  // reset string index iterator
                } else {    // if char at index is 0
                    i++;    // increment string index iterator to check next index
                    if (i == difficulty) {  // if string index iterator == difficulty, then nonce must be found
                        foundNonce = true;
                        break;
                    }
                }
            }
        }
        return hash;
    }

    /**
     * Simple getter of difficulty instance variable.
     * @return user-defined difficulty.
     */
    public int getDifficulty() {
        return difficulty;
    }

    /**
     * Set difficulty of this block hash.
     * @param difficulty
     */
    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * Override toString() method.
     * @return A JSON representation of all of this block's data is returned.
     */
    @Override
    public String toString() {
        // Build JSON string with this block's 
        String blockJson =
                "{" +
                "\"index\" : " + index + "," +
                "\"time stamp \" : \"" + timestamp + "\"," +
                "\"Tx \": \"" + data + "\"," +
                "\"PrevHash\" : \"" + previousHash + "\"," +
                "\"nonce\" : " + nonce + "," +
                "\"difficulty\": " + difficulty +
                "}";
        return blockJson;
    }

    /**
     * Simple setter for block's stored previousHash
     * @param previousHash - previous hash defined by the block chain
     */
    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    /**
     * Simple getter for block's previousHash.
     * @return stored previousHash.
     */
    public String getPreviousHash() {
        return previousHash;
    }

    /**
     * Simple getter for block's index in the blockchain
     * @return block index
     */
    public int getIndex() {
        return index;
    }

    /**
     * Simple setter for block index
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * Simple setter for block timestamp
     * @param timestamp
     */
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Simple getter for block's timestamp
     * @return block timestamp
     */
    public Timestamp getTimestamp() {
        return timestamp;
    }

    /**
     * Simple getter for block's data
     * @return block data
     */
    public String getData() {
        return data;
    }

    /**
     * Simple setter of block's data
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    // no routine defined in javadoc
    public static void main(String[] args) { }

}
